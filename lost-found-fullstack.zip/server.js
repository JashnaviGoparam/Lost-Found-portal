require("dotenv").config();
const express=require("express"),mongoose=require("mongoose"),bcrypt=require("bcryptjs"),jwt=require("jsonwebtoken"),nodemailer=require("nodemailer"),path=require("path");
const app=express();app.use(express.json());app.use(express.static(path.join(__dirname,"public")));
const SECRET=process.env.JWT_SECRET||"change-me";
const User=mongoose.model("User",new mongoose.Schema({name:String,email:{type:String,unique:true,lowercase:true},pass:String,role:{type:String,default:"student"},code:String,codeExp:Date},{timestamps:true}));
const Item=mongoose.model("Item",new mongoose.Schema({type:String,title:String,cat:String,desc:String,loc:String,date:String,contact:String,by:{type:mongoose.Schema.Types.ObjectId,ref:"User"},byName:String,byEmail:String,status:{type:String,default:"pending"}},{timestamps:true}));
const sign=u=>jwt.sign({id:u._id},SECRET,{expiresIn:"7d"});
const pub=u=>({name:u.name,email:u.email,role:u.role});
const w=f=>(req,res)=>f(req,res).catch(e=>res.status(400).json({error:e.message}));
const fail=m=>{throw new Error(m)};
async function auth(req,res,next){try{const p=jwt.verify((req.headers.authorization||"").slice(7),SECRET);req.user=await User.findById(p.id);if(!req.user)throw 0;next()}catch(e){res.status(401).json({error:"Please login again"})}}
const admin=(req,res,next)=>req.user.role=="admin"?next():res.status(403).json({error:"Admins only"});
const mailer=process.env.SMTP_HOST?nodemailer.createTransport({host:process.env.SMTP_HOST,port:+process.env.SMTP_PORT||587,auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASS}}):null;
async function sendMail(to,subject,text){if(!mailer){console.log("[MAIL not configured] to:",to,text);return}await mailer.sendMail({from:process.env.SMTP_USER,to,subject,text})}

app.post("/api/signup",w(async(req,res)=>{const{name,email,password}=req.body;if(!name||!email||!password||password.length<6)fail("Name, email and 6+ char password required");
 if(await User.findOne({email:email.toLowerCase()}))fail("Email already registered");
 const u=await User.create({name,email,pass:await bcrypt.hash(password,10)});res.json({token:sign(u),user:pub(u)})}));
app.post("/api/login",w(async(req,res)=>{const{email,password,admin:wantAdmin}=req.body;const u=await User.findOne({email:(email||"").toLowerCase()});
 if(!u||!(await bcrypt.compare(password||"",u.pass)))fail("Invalid email or password");
 if(wantAdmin&&u.role!="admin")fail("This is not an admin account");if(!wantAdmin&&u.role=="admin")fail("Admins: please use Admin login");
 res.json({token:sign(u),user:pub(u)})}));
app.post("/api/forgot",w(async(req,res)=>{const u=await User.findOne({email:(req.body.email||"").toLowerCase()});if(!u)fail("Email not found");
 const code=String(Math.floor(100000+Math.random()*900000));u.code=await bcrypt.hash(code,8);u.codeExp=new Date(Date.now()+10*60000);await u.save();
 await sendMail(u.email,"Lost & Found password reset code","Hi "+u.name+", your reset code is "+code+". It is valid for 10 minutes.");res.json({ok:true})}));
app.post("/api/reset",w(async(req,res)=>{const{email,code,password}=req.body;const u=await User.findOne({email:(email||"").toLowerCase()});
 if(!u||!u.code||u.codeExp<new Date()||!(await bcrypt.compare(code||"",u.code)))fail("Invalid or expired code");if(!password||password.length<6)fail("Password too short");
 u.pass=await bcrypt.hash(password,10);u.code=undefined;u.codeExp=undefined;await u.save();res.json({ok:true})}));
app.get("/api/me",auth,(req,res)=>res.json(pub(req.user)));

const esc=s=>s.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");
app.get("/api/items",auth,w(async(req,res)=>{const{q,cat,type,mine}=req.query;const f={status:{$ne:"removed"}};if(cat)f.cat=cat;if(type)f.type=type;if(mine)f.by=req.user._id;
 if(q){const r=new RegExp(esc(q),"i");f.$or=[{title:r},{desc:r},{loc:r}]}res.json(await Item.find(f).sort({createdAt:-1}))}));
app.post("/api/items",auth,w(async(req,res)=>{const b=req.body;if(!["lost","found"].includes(b.type)||!b.title||!b.loc||!b.contact)fail("Title, location and contact required");
 res.json(await Item.create({type:b.type,title:b.title,cat:b.cat,desc:b.desc,loc:b.loc,date:b.date,contact:b.contact,by:req.user._id,byName:req.user.name,byEmail:req.user.email}))}));
app.patch("/api/items/:id/status",auth,w(async(req,res)=>{const it=await Item.findById(req.params.id);if(!it)fail("Not found");const s=req.body.status;
 if(req.user.role!="admin"){if(String(it.by)!=String(req.user._id)||s!="recovered")fail("Not allowed")}
 if(!["pending","verified","recovered"].includes(s))fail("Bad status");it.status=s;await it.save();res.json(it)}));
app.delete("/api/items/:id",auth,admin,w(async(req,res)=>{await Item.findByIdAndDelete(req.params.id);res.json({ok:true})}));
app.get("/api/admin/users",auth,admin,w(async(req,res)=>res.json((await User.find().sort({createdAt:-1})).map(u=>({...pub(u),joined:u.createdAt})))));
app.post("/api/admin/admins",auth,admin,w(async(req,res)=>{const{name,email,password}=req.body;if(!name||!email||!password||password.length<6)fail("All fields required (password 6+)");
 if(await User.findOne({email:email.toLowerCase()}))fail("Email already registered");await User.create({name,email,pass:await bcrypt.hash(password,10),role:"admin"});res.json({ok:true})}));

mongoose.connect(process.env.MONGO_URI).then(async()=>{
 const ae=(process.env.ADMIN_EMAIL||"admin@mits.edu").toLowerCase();
 if(!(await User.findOne({email:ae})))await User.create({name:"Admin",email:ae,pass:await bcrypt.hash(process.env.ADMIN_PASSWORD||"admin123",10),role:"admin"});
 app.listen(process.env.PORT||3000,()=>console.log("Running on port "+(process.env.PORT||3000)))}).catch(e=>console.error("DB error:",e.message));
