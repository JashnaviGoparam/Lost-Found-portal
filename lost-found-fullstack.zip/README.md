# Campus Lost & Found Portal (full stack)
Node + Express + MongoDB. Data is shared across all devices.

## Run locally
1. Install Node 18+. In this folder: `npm install`
2. Copy `.env.example` to `.env` and fill in MONGO_URI (free MongoDB Atlas cluster), JWT_SECRET, and SMTP details for reset emails.
3. `npm start` then open http://localhost:3000

## Deploy (Render.com, free)
New Web Service -> connect your GitHub repo -> Build: `npm install` -> Start: `npm start` -> add the same variables from .env in Environment.

Default admin: ADMIN_EMAIL / ADMIN_PASSWORD from .env (created on first start). Change the password after first login.
